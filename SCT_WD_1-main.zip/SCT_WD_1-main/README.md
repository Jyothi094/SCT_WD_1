# SCT_WD_1
Contains code/files for Task 1
